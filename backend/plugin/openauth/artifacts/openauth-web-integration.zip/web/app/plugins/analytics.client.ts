export default defineNuxtPlugin(() => {
  // 授权页面不得加载统计/会话回放脚本或上报授权参数。
  if (window.location.pathname.startsWith('/openauth/'))
    return
  const config = useRuntimeConfig()
  const baseUrl = config.public.analyticsBaseUrl.replace(/\/$/, '')
  const siteKey = config.public.analyticsSiteKey

  if (!baseUrl || !siteKey)
    return

  useHead({
    script: [
      {
        key: 'web-analytics',
        src: `${baseUrl}/script.js`,
        defer: true,
        'data-site': siteKey,
        'data-endpoint': baseUrl,
      },
    ],
  })
})
