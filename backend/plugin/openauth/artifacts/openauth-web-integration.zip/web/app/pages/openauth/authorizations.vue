<script setup lang="ts">
import { scopeLabel } from '~/utils/openauth'
import LoginModal from '~/components/layout/LoginModal.vue'
import { siteInfo } from '~/utils/site'
useSeoMeta({ title: '应用授权管理', robots: 'noindex, nofollow, noarchive' })
useHead({ meta: [{ name: 'referrer', content: 'no-referrer' }] })
const token = useCookie<string | null>('web_token')
const loginVisible = ref(false)
const loading = ref(false)
const error = ref('')
const pending = ref<string | null>(null)
interface Grant { id: number; application_client_id: string; application_name: string; scopes: string[]; status: string }
const grants = ref<Grant[]>([])
async function load() {
  if (!token.value) { grants.value = []; return }
  loading.value = true
  error.value = ''
  try {
    const response = await $fetch<{ code: number; data: Grant[] }>('/api/openauth/authorizations', {
      headers: { authorization: `Bearer ${token.value}` }, retry: 0,
    })
    if (response.code !== 200) throw new Error()
    grants.value = response.data
  }
  catch { error.value = '暂时无法加载授权，请确认登录状态后重试' }
  finally { loading.value = false }
}
async function revoke(grant: Grant) {
  if (pending.value !== grant.application_client_id || loading.value) return
  loading.value = true
  try {
    const result = await $fetch<{ code: number }>('/api/openauth/revoke', {
      method: 'POST', headers: { authorization: `Bearer ${token.value}` }, retry: 0,
      body: { client_id: grant.application_client_id },
    })
    if (result.code !== 200) throw new Error()
    pending.value = null
    await load()
  }
  catch { error.value = '解绑失败，授权状态未确认，请稍后重试' }
  finally { loading.value = false }
}
onMounted(load)
watch(token, load)
</script>

<template>
  <main class="grants-page container">
    <div class="page-head">
      <NuxtLink to="/" class="site-brand">
        <span class="brand-mark" aria-hidden="true">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <path d="M22 10L12 5 2 10l10 5 10-5z" fill="#fff" />
            <path d="M6 12.2v4.3c0 1.66 2.69 3 6 3s6-1.34 6-3v-4.3l-6 3-6-3z" fill="rgba(255,255,255,0.72)" />
          </svg>
        </span>
        {{ siteInfo.name }} <span class="brand-divider">开放平台</span>
      </NuxtLink>
      <h1>应用授权管理</h1>
      <p class="lead">解绑会使这个应用在所有设备上的授权失效，不删除你的账号或业务数据。</p>
    </div>

    <div v-if="error" class="notice error" role="alert">{{ error }}</div>

    <button v-if="!token" class="empty-card" type="button" @click="loginVisible = true">
      <span class="empty-icon" aria-hidden="true">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></svg>
      </span>
      <span class="empty-title">登录后查看已授权的应用</span>
      <span class="empty-desc">使用你的{{ siteInfo.name }}账号登录，管理应用与设备的授权关系</span>
    </button>

    <div v-else-if="loading" class="empty-card static" role="status">
      <span class="spinner" aria-hidden="true" />
      <span class="empty-title">正在加载授权列表…</span>
    </div>

    <div v-else-if="!grants.length" class="empty-card static">
      <span class="empty-icon" aria-hidden="true">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8v13H3V8" /><path d="M1 3h22v5H1z" /><path d="M10 12h4" /></svg>
      </span>
      <span class="empty-title">暂无应用授权</span>
      <span class="empty-desc">当你在其他应用中确认授权后，会在这里出现管理入口</span>
    </div>

    <TransitionGroup v-else name="card" tag="div" class="grant-list">
      <article v-for="grant in grants" :key="grant.id" class="grant-card">
        <div class="grant-main">
          <div class="app-icon" aria-hidden="true">{{ grant.application_name.slice(0, 1) }}</div>
          <div class="grant-info">
            <div class="grant-title-row">
              <h2>{{ grant.application_name }}</h2>
              <span v-if="grant.status !== 'active'" class="status-chip revoked">已解绑</span>
            </div>
            <div class="scope-tags">
              <span v-for="s in grant.scopes" :key="s" class="scope-tag">{{ scopeLabel(s) }}</span>
            </div>
          </div>
        </div>
        <div v-if="grant.status === 'active'" class="grant-actions">
          <template v-if="pending === grant.application_client_id">
            <div class="confirm-bar">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" /><path d="M12 9v4M12 17h.01" /></svg>
              <p>确定解绑此应用的所有设备？下次使用需要重新授权。</p>
            </div>
            <div class="action-row">
              <button class="btn danger sm" type="button" :disabled="loading" @click="revoke(grant)">{{ loading ? '解绑中…' : '确认解绑' }}</button>
              <button class="btn secondary sm" type="button" :disabled="loading" @click="pending = null">取消</button>
            </div>
          </template>
          <button v-else class="btn secondary sm" type="button" :disabled="loading" @click="pending = grant.application_client_id">解绑应用</button>
        </div>
      </article>
    </TransitionGroup>

    <LoginModal v-model="loginVisible" @success="load" />
  </main>
</template>

<style scoped>
.grants-page {
  max-width: 760px;
  padding: var(--space-7) var(--space-5) var(--space-9);
  min-height: 70vh;
}

.page-head { margin-bottom: var(--space-5); }

.site-brand {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  color: var(--ink-900);
  font-weight: 750;
  font-size: 15px;
  text-decoration: none;
  transition: opacity 0.2s;
}

.site-brand:hover { opacity: 0.8; }

.brand-mark {
  display: grid;
  place-items: center;
  width: 34px;
  height: 34px;
  border-radius: 10px;
  background: linear-gradient(135deg, var(--brand-500) 0%, var(--accent-violet) 100%);
  box-shadow: 0 4px 10px rgba(47, 107, 255, 0.35);
}

.brand-divider {
  color: var(--ink-400);
  font-size: 12px;
  border-left: 1px solid var(--ink-300);
  padding-left: 10px;
  font-weight: 500;
}

h1 {
  font-size: 30px;
  letter-spacing: -0.02em;
  color: var(--ink-900);
  margin: var(--space-5) 0 var(--space-2);
  line-height: 1.25;
}

.lead {
  color: var(--ink-500);
  font-size: 14px;
  line-height: 1.75;
  margin: 0;
}

.grant-list {
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
}

.grant-card {
  padding: var(--space-5);
  border: 1px solid var(--ink-200);
  border-radius: var(--radius-lg);
  background: var(--bg-card);
  box-shadow: var(--shadow-sm);
  transition: box-shadow 0.25s var(--ease-out), border-color 0.25s;
}

.grant-card:hover { box-shadow: var(--shadow-md); }

.grant-main {
  display: flex;
  gap: var(--space-4);
  align-items: center;
}

.app-icon {
  width: 48px;
  height: 48px;
  flex-shrink: 0;
  border-radius: 14px;
  background: linear-gradient(135deg, var(--brand-500) 0%, var(--accent-violet) 100%);
  display: grid;
  place-items: center;
  color: #fff;
  font-size: 21px;
  font-weight: 700;
  box-shadow: 0 6px 14px rgba(47, 107, 255, 0.3);
}

.grant-info { flex: 1; min-width: 0; }

.grant-title-row {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  margin-bottom: 7px;
}

.grant-title-row h2 {
  font-size: 17px;
  color: var(--ink-900);
  margin: 0;
  letter-spacing: -0.01em;
}

.status-chip {
  flex-shrink: 0;
  padding: 2px 10px;
  border-radius: var(--radius-full);
  font-size: 11.5px;
  font-weight: 600;
}

.status-chip.revoked {
  background: var(--ink-200);
  color: var(--ink-500);
}

.scope-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.scope-tag {
  padding: 3px 10px;
  border-radius: var(--radius-full);
  background: var(--brand-50);
  color: var(--brand-600);
  font-size: 12px;
  font-weight: 550;
}

html.dark .scope-tag { color: var(--brand-200); }

.grant-actions {
  margin-top: var(--space-4);
  padding-top: var(--space-4);
  border-top: 1px dashed var(--ink-200);
}

.confirm-bar {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  margin-bottom: var(--space-3);
  padding: 11px 13px;
  background: var(--accent-amber-soft);
  border-radius: var(--radius-sm);
  font-size: 13px;
  line-height: 1.6;
  color: #b26205;
}

html.dark .confirm-bar { color: #f5b95f; }

.confirm-bar svg { flex-shrink: 0; margin-top: 2px; }

.confirm-bar p { margin: 0; }

.action-row { display: flex; gap: var(--space-2); }

.btn {
  min-height: 44px;
  padding: 10px 20px;
  font-size: 14px;
  font-weight: 650;
  border-radius: var(--radius-sm);
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  transition: background-color 0.2s, transform 0.2s, border-color 0.2s;
}

.btn.sm { min-height: 38px; padding: 8px 16px; font-size: 13.5px; }

.btn.danger {
  background: #d92d20;
  border: 1px solid #d92d20;
  color: #fff;
}

.btn.danger:hover:not(:disabled) { background: #b42318; }

.btn.secondary {
  background: var(--bg-elevated);
  border: 1px solid var(--ink-300);
  color: var(--ink-700);
}

.btn.secondary:hover:not(:disabled) { border-color: var(--brand-500); color: var(--brand-600); }

.btn:disabled { opacity: 0.5; cursor: not-allowed; }

.empty-card {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--space-2);
  width: 100%;
  padding: var(--space-8) var(--space-5);
  border: 1.5px dashed var(--ink-300);
  border-radius: var(--radius-lg);
  background: var(--bg-card);
  cursor: pointer;
  transition: border-color 0.2s, background-color 0.2s;
}

.empty-card.static { cursor: default; }

.empty-card:not(.static):hover {
  border-color: var(--brand-500);
  background: var(--brand-50);
}

.empty-icon {
  display: grid;
  place-items: center;
  width: 56px;
  height: 56px;
  margin-bottom: var(--space-1);
  border-radius: 16px;
  background: var(--brand-50);
  color: var(--brand-500);
}

.empty-title {
  font-size: 15.5px;
  font-weight: 700;
  color: var(--ink-900);
}

.empty-desc {
  font-size: 13px;
  line-height: 1.7;
  color: var(--ink-500);
  text-align: center;
  max-width: 340px;
}

.notice.error {
  background: #fff1f0;
  color: #a53232;
  padding: 13px 15px;
  border-radius: var(--radius-sm);
  font-size: 13.5px;
  margin-bottom: var(--space-4);
}

html.dark .notice.error { background: #3a1a1e; color: #f3a5a8; }

.spinner {
  width: 22px;
  height: 22px;
  border: 2.5px solid rgba(47, 107, 255, 0.2);
  border-top-color: var(--brand-500);
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
  margin: var(--space-2) 0;
}

@keyframes spin { to { transform: rotate(360deg); } }

.card-enter-active, .card-leave-active { transition: all 0.3s var(--ease-out); }
.card-enter-from, .card-leave-to { opacity: 0; transform: translateY(10px); }
.card-leave-active { position: absolute; max-width: 100%; }
.card-move { transition: transform 0.3s var(--ease-out); }

button:focus-visible, a:focus-visible {
  outline: 3px solid var(--brand-200);
  outline-offset: 3px;
}

@media (max-width: 560px) {
  .grants-page { padding: var(--space-5) var(--space-4) var(--space-7); }
  h1 { font-size: 25px; }
  .grant-card { padding: var(--space-4); }
}
</style>
