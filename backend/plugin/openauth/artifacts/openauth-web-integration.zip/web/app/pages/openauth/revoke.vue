<script setup lang="ts">
import LoginModal from '~/components/layout/LoginModal.vue'
import { siteInfo } from '~/utils/site'

definePageMeta({ layout: false })
useSeoMeta({ title: '解除设备授权', robots: 'noindex, nofollow, noarchive' })
useHead({ meta: [{ name: 'referrer', content: 'no-referrer' }] })
const route = useRoute()
const token = useCookie<string | null>('web_token')
const loginVisible = ref(false)
const loading = ref(false)
const submitting = ref(false)
const confirmed = ref(false)
const completed = ref(false)
const error = ref('')
const preview = ref<{ application_name: string; active: boolean } | null>(null)
const ticket = computed(() => typeof route.query.ticket === 'string' && /^[A-Za-z0-9_-]{43}$/.test(route.query.ticket) ? route.query.ticket : '')
let revision = 0
let validatedToken: string | null = null

async function load() {
  const current = ++revision
  confirmed.value = false
  preview.value = null
  validatedToken = null
  loading.value = false
  if (!ticket.value) { error.value = '解绑链接无效，请从对话重新发起'; return }
  if (!token.value || completed.value) return
  loading.value = true
  error.value = ''
  const credential = token.value
  try {
    const result = await $fetch<{ code: number; data: { application_name: string; active: boolean } }>('/api/openauth/device-revoke/preview', {
      method: 'POST', body: { ticket: ticket.value }, headers: { authorization: `Bearer ${credential}` }, retry: 0,
    })
    if (current !== revision || token.value !== credential) return
    if (result.code !== 200) throw new Error()
    preview.value = result.data
    validatedToken = credential
  }
  catch { if (current === revision) error.value = '无法确认此设备，请使用同一账号登录，或重新获取解绑链接' }
  finally { if (current === revision) loading.value = false }
}

async function revoke() {
  if (!confirmed.value || !preview.value || submitting.value || completed.value) return
  if (!validatedToken || token.value !== validatedToken) { await load(); return }
  const current = revision
  submitting.value = true
  error.value = ''
  try {
    const result = await $fetch<{ code: number }>('/api/openauth/device-revoke', {
      method: 'POST', body: { ticket: ticket.value }, headers: { authorization: `Bearer ${validatedToken}` }, retry: 0,
    })
    if (current !== revision) return
    if (result.code !== 200) throw new Error()
    completed.value = true
  }
  catch { if (current === revision) error.value = '解绑结果未确认，请重新检查状态后重试' }
  finally { submitting.value = false }
}
onMounted(load)
watch(token, load)
watch(() => route.fullPath, () => { completed.value = false; load() })
</script>

<template>
  <main class="revoke-page">
    <div class="page-glow" aria-hidden="true" />
    <section class="revoke-card">
      <NuxtLink to="/" class="site-brand">
        <span class="brand-mark" aria-hidden="true">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <path d="M22 10L12 5 2 10l10 5 10-5z" fill="#fff" />
            <path d="M6 12.2v4.3c0 1.66 2.69 3 6 3s6-1.34 6-3v-4.3l-6 3-6-3z" fill="rgba(255,255,255,0.72)" />
          </svg>
        </span>
        {{ siteInfo.name }} <span class="brand-divider">开放平台</span>
      </NuxtLink>

      <template v-if="completed">
        <div class="state-hero success" role="img" aria-label="已解除授权">
          <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5" /></svg>
        </div>
        <h1>已解除设备授权</h1>
        <p class="lead">当前设备的 youanshang 授权已失效。其他设备与账号数据不受影响，你可以关闭此页面。</p>
      </template>

      <template v-else>
        <div class="state-hero warn" role="img" aria-label="解除授权">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" /><path d="M12 9v4M12 17h.01" /></svg>
        </div>
        <h1>解除当前设备授权</h1>
        <p class="lead">打开本页面不会自动解绑。请核对应用后，由你本人确认。</p>

        <div v-if="error" class="notice error" role="alert">{{ error }}</div>

        <button v-if="!token && ticket" class="btn primary block" type="button" @click="loginVisible = true">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></svg>
          登录以确认
        </button>
        <div v-else-if="loading" class="notice" role="status">
          <span class="spinner" aria-hidden="true" />正在核对设备…
        </div>

        <template v-else-if="preview">
          <div class="application">
            <div class="app-icon" aria-hidden="true">{{ preview.application_name.slice(0, 1) }}</div>
            <div class="app-meta">
              <p class="app-label">将解除授权的应用</p>
              <h2>{{ preview.application_name }}</h2>
            </div>
          </div>
          <div v-if="!preview.active" class="notice">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10" /><path d="M12 8v4M12 16h.01" /></svg>
            此设备授权已失效，无需重复解绑。
          </div>
          <template v-else>
            <label class="consent-check">
              <input v-model="confirmed" type="checkbox" :disabled="submitting">
              <span>我确认解除这个应用在当前设备上的授权</span>
            </label>
            <button class="btn danger block" type="button" :disabled="!confirmed || submitting" @click="revoke">
              <span v-if="submitting" class="spinner" aria-hidden="true" />
              {{ submitting ? '正在解绑…' : '确认解除授权' }}
            </button>
          </template>
        </template>
        <button v-else-if="token && ticket" class="btn secondary block" type="button" @click="load">重新核对</button>

        <p class="footer-note">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /></svg>
          也可前往<NuxtLink to="/openauth/authorizations">应用授权管理</NuxtLink>解绑整个应用的全部设备。
        </p>
      </template>
    </section>
    <LoginModal v-model="loginVisible" @success="load" />
  </main>
</template>

<style scoped>
.revoke-page {
  position: relative;
  min-height: 100vh;
  display: grid;
  place-items: center;
  padding: var(--space-7) var(--space-5);
  background: var(--bg-soft);
  overflow: hidden;
}

.page-glow {
  position: absolute;
  inset: 0;
  pointer-events: none;
  background:
    radial-gradient(520px 320px at 88% -6%, var(--accent-amber-soft), transparent 65%),
    radial-gradient(460px 300px at 4% 104%, var(--brand-100), transparent 68%);
}

html.dark .page-glow { opacity: 0.5; }

.revoke-card {
  position: relative;
  width: 100%;
  max-width: 540px;
  padding: var(--space-7) var(--space-6) var(--space-6);
  background: var(--bg-elevated);
  border: 1px solid var(--ink-200);
  border-radius: var(--radius-xl);
  box-shadow: var(--shadow-lg);
}

.site-brand {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  color: var(--ink-900);
  font-weight: 750;
  font-size: 15px;
  text-decoration: none;
  transition: opacity 0.2s;
}

.site-brand:hover { opacity: 0.8; }

.brand-mark {
  display: grid;
  place-items: center;
  width: 34px;
  height: 34px;
  border-radius: 10px;
  background: linear-gradient(135deg, var(--brand-500) 0%, var(--accent-violet) 100%);
  box-shadow: 0 4px 10px rgba(47, 107, 255, 0.35);
}

.brand-divider {
  color: var(--ink-400);
  font-size: 12px;
  border-left: 1px solid var(--ink-300);
  padding-left: 10px;
  font-weight: 500;
}

.state-hero {
  display: grid;
  place-items: center;
  width: 64px;
  height: 64px;
  margin: var(--space-6) 0 var(--space-4);
  border-radius: 18px;
}

.state-hero.warn {
  background: var(--accent-amber-soft);
  color: #d97706;
}

html.dark .state-hero.warn { color: #fbbf24; }

.state-hero.success {
  background: var(--accent-green-soft);
  color: var(--accent-green);
}

h1 {
  font-size: 26px;
  letter-spacing: -0.02em;
  color: var(--ink-900);
  margin: 0 0 var(--space-3);
  line-height: 1.25;
}

.lead {
  color: var(--ink-500);
  font-size: 14px;
  line-height: 1.75;
  margin: 0;
}

.application {
  display: flex;
  gap: var(--space-4);
  align-items: center;
  margin: var(--space-5) 0;
  padding: var(--space-4);
  background: var(--bg-soft);
  border: 1px solid var(--ink-200);
  border-radius: var(--radius-md);
}

.app-icon {
  width: 48px;
  height: 48px;
  flex-shrink: 0;
  border-radius: 14px;
  background: linear-gradient(135deg, var(--brand-500) 0%, var(--accent-violet) 100%);
  display: grid;
  place-items: center;
  color: #fff;
  font-size: 21px;
  font-weight: 700;
  box-shadow: 0 6px 14px rgba(47, 107, 255, 0.3);
}

.app-label {
  margin: 0 0 2px;
  font-size: 12px;
  color: var(--ink-400);
}

.app-meta h2 {
  margin: 0;
  font-size: 17px;
  color: var(--ink-900);
}

.consent-check {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  font-size: 14px;
  line-height: 1.6;
  color: var(--ink-700);
  margin: var(--space-4) 0;
  cursor: pointer;
}

.consent-check input { margin-top: 4px; accent-color: #d97706; }

.btn {
  min-height: 48px;
  padding: 12px 22px;
  font-size: 15px;
  font-weight: 650;
  border-radius: var(--radius-sm);
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  transition: background-color 0.2s, transform 0.2s, border-color 0.2s;
}

.btn.block { width: 100%; }

.btn.danger {
  background: #d92d20;
  border: 1px solid #d92d20;
  color: #fff;
  box-shadow: 0 6px 16px rgba(217, 45, 32, 0.28);
}

.btn.danger:hover:not(:disabled) { background: #b42318; transform: translateY(-1px); }

.btn.primary {
  background: var(--brand-500);
  border: 1px solid var(--brand-500);
  color: #fff;
  box-shadow: 0 6px 16px rgba(47, 107, 255, 0.3);
}

.btn.primary:hover:not(:disabled) { background: var(--brand-600); }

.btn.secondary {
  background: var(--bg-elevated);
  border: 1px solid var(--ink-300);
  color: var(--ink-700);
}

.btn.secondary:hover:not(:disabled) { border-color: var(--brand-500); color: var(--brand-600); }

.btn:disabled { opacity: 0.5; cursor: not-allowed; }

.notice {
  display: flex;
  align-items: flex-start;
  gap: 9px;
  background: var(--brand-50);
  color: var(--ink-700);
  padding: 13px 15px;
  border-radius: var(--radius-sm);
  margin: var(--space-4) 0;
  font-size: 13.5px;
  line-height: 1.7;
}

.notice svg { flex-shrink: 0; margin-top: 3px; color: var(--brand-500); }

.notice.error {
  background: #fff1f0;
  color: #a53232;
}

html.dark .notice.error { background: #3a1a1e; color: #f3a5a8; }

.footer-note {
  display: flex;
  align-items: flex-start;
  gap: 7px;
  margin: var(--space-5) 0 0;
  padding-top: var(--space-4);
  border-top: 1px solid var(--ink-200);
  font-size: 12px;
  line-height: 1.7;
  color: var(--ink-400);
}

.footer-note svg { flex-shrink: 0; margin-top: 2px; }
.footer-note a { color: var(--brand-500); font-weight: 600; }

.spinner {
  width: 15px;
  height: 15px;
  border: 2px solid rgba(255, 255, 255, 0.4);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
  flex-shrink: 0;
}

.notice .spinner {
  border-color: rgba(47, 107, 255, 0.25);
  border-top-color: var(--brand-500);
}

@keyframes spin { to { transform: rotate(360deg); } }

button:focus-visible, input:focus-visible, a:focus-visible {
  outline: 3px solid var(--brand-200);
  outline-offset: 3px;
}

@media (max-width: 560px) {
  .revoke-card { padding: var(--space-6) var(--space-5) var(--space-5); }
  .revoke-page { padding: var(--space-5) var(--space-4); }
  h1 { font-size: 23px; }
}
</style>
