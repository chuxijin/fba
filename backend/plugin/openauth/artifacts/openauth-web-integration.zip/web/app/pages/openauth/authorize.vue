<script setup lang="ts">
import { authorizationCallback, parseAuthorizationQuery, scopeLabel } from '~/utils/openauth'
import type { AuthorizationPreview, AuthorizationRequest } from '~/utils/openauth'
import { siteInfo } from '~/utils/site'
import LoginModal from '~/components/layout/LoginModal.vue'

definePageMeta({ layout: false })
useSeoMeta({ title: '确认应用授权', robots: 'noindex, nofollow, noarchive' })
useHead({ meta: [{ name: 'referrer', content: 'no-referrer' }] })

const route = useRoute()
const token = useCookie<string | null>('web_token')
const loginVisible = ref(false)
const loading = ref(false)
const submitting = ref(false)
const error = ref('')
const request = shallowRef<AuthorizationRequest | null>(null)
const preview = shallowRef<AuthorizationPreview | null>(null)
const account = ref('')
const consent = ref(false)
const returnUrl = ref('')
const manualCode = ref('')
const copied = ref(false)
const callbackHost = computed(() => request.value ? new URL(request.value.redirect_uri).host : '')
let revision = 0
let validatedToken: string | null = null

interface Envelope<T> { code: number; msg: string; data: T }

function messageOf(value: unknown) {
  const err = value as { statusCode?: number; data?: { msg?: string }; message?: string }
  if (err.statusCode === 401) {
    token.value = null
    return '登录已过期，请重新登录；尚未授予任何权限'
  }
  return err.data?.msg || err.message || '请求失败，请稍后重试'
}

async function loadPreview() {
  const current = ++revision
  loading.value = false
  consent.value = false
  preview.value = null
  request.value = null
  validatedToken = null
  account.value = ''
  error.value = ''
  returnUrl.value = ''
  manualCode.value = ''
  try { request.value = parseAuthorizationQuery(route.query) }
  catch { error.value = '授权链接无效，请关闭页面并从 CLI 重新发起登录'; return }
  if (!token.value) return
  loading.value = true
  const loginToken = token.value
  try {
    const headers = { authorization: `Bearer ${loginToken}` }
    const [application, user] = await Promise.all([
      $fetch<Envelope<AuthorizationPreview>>('/api/openauth/authorize/preview',
        { method: 'POST', body: request.value, headers, retry: 0 }),
      $fetch<Envelope<{ nickname?: string; username?: string }>>('/api/sys/users/me', { headers, retry: 0 }),
    ])
    if (current !== revision || token.value !== loginToken) return
    if (application.code !== 200 || user.code !== 200) throw new Error('无法确认应用或当前登录账号')
    preview.value = application.data
    account.value = user.data.nickname || user.data.username || '当前账号'
    validatedToken = loginToken
  }
  catch (value) { if (current === revision) error.value = messageOf(value) }
  finally { if (current === revision) loading.value = false }
}

async function approve() {
  if (!request.value || !preview.value || !consent.value || submitting.value) return
  if (!validatedToken || token.value !== validatedToken) { await loadPreview(); return }
  const submitted = request.value
  const current = revision
  submitting.value = true
  error.value = ''
  try {
    const response = await $fetch<Envelope<{ code: string; state: string | null; redirect_uri: string }>>(
      '/api/openauth/authorize', { method: 'POST', body: submitted, retry: 0,
        headers: { authorization: `Bearer ${validatedToken}` } },
    )
    if (current !== revision) return
    if (response.code !== 200) throw new Error('授权未完成，请重新发起登录')
    returnUrl.value = authorizationCallback(submitted, response.data)
    manualCode.value = response.data.code
    window.location.assign(returnUrl.value)
  }
  catch (value) { if (current === revision) error.value = messageOf(value) }
  finally { submitting.value = false }
}

function deny() {
  if (submitting.value) return
  // 只有服务端验证过应用与回调地址，才允许跳转回调用方。
  if (preview.value && request.value) window.location.assign(authorizationCallback(request.value, { denied: true }))
  else error.value = '本次授权未授予任何权限，你可以安全关闭此页面'
}

async function copyCode() {
  if (!manualCode.value) return
  try {
    await navigator.clipboard.writeText(manualCode.value)
    copied.value = true
    setTimeout(() => { copied.value = false }, 2000)
  }
  catch { /* 剪贴板不可用时保持手动选择 */ }
}

onMounted(loadPreview)
watch(() => route.fullPath, loadPreview)
watch(token, loadPreview)
</script>

<template>
  <main class="consent-page">
    <div class="page-glow" aria-hidden="true" />
    <section class="consent-card" aria-labelledby="consent-title">
      <NuxtLink to="/" class="site-brand">
        <span class="brand-mark" aria-hidden="true">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <path d="M22 10L12 5 2 10l10 5 10-5z" fill="#fff" />
            <path d="M6 12.2v4.3c0 1.66 2.69 3 6 3s6-1.34 6-3v-4.3l-6 3-6-3z" fill="rgba(255,255,255,0.72)" />
          </svg>
        </span>
        {{ siteInfo.name }} <span class="brand-divider">开放平台</span>
      </NuxtLink>

      <template v-if="error">
        <div class="state-icon error" role="img" aria-label="出错">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10" /><path d="M12 8v4M12 16h.01" /></svg>
        </div>
      </template>
      <div v-if="error" class="notice error" role="alert">{{ error }}</div>
      <div v-if="loading" class="notice" role="status">
        <span class="spinner" aria-hidden="true" />正在核对应用与当前账号…
      </div>

      <template v-else-if="!token && request">
        <p class="eyebrow">安全授权 · 由你决定</p>
        <h1 id="consent-title">连接你的{{ siteInfo.name }}账号</h1>
        <p class="intro">仅在你确认后，应用才能以你的身份访问以下能力。站内密码不会提供给应用。</p>
        <div class="notice">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></svg>
          请先登录本站，再核对申请授权的应用。登录不会自动同意授权。
        </div>
        <button class="btn primary block" type="button" @click="loginVisible = true">登录以继续</button>
      </template>

      <template v-else-if="preview && request">
        <p class="eyebrow">安全授权 · 由你决定</p>
        <h1 id="consent-title">确认连接以下应用</h1>
        <div class="application">
          <div class="app-icon" aria-hidden="true">{{ preview.name.slice(0, 1) }}</div>
          <div class="app-meta">
            <h2>{{ preview.name }}</h2>
            <p>{{ preview.description || '此应用正在申请连接你的账号' }}</p>
          </div>
        </div>
        <div class="account">
          <span class="account-label">授权账号</span>
          <span class="account-name">{{ account }}</span>
        </div>
        <h3 class="section-title">本次申请的权限</h3>
        <ul class="permissions">
          <li v-for="scope in preview.scopes" :key="scope">
            <span class="perm-check" aria-hidden="true">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5" /></svg>
            </span>{{ scopeLabel(scope) }}
          </li>
        </ul>
        <p v-if="preview.already_authorized" class="muted">你曾授权过此应用，本次仍需确认连接。</p>
        <div class="callback-row">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" /><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" /></svg>
          确认后返回：<span class="callback-host">{{ callbackHost }}</span>
        </div>
        <label class="consent-check">
          <input v-model="consent" type="checkbox" :disabled="submitting">
          <span>我已核对应用与权限，同意连接此账号</span>
        </label>
        <div class="actions">
          <button class="btn secondary" type="button" :disabled="submitting" @click="deny">取消</button>
          <button class="btn primary" type="button" :disabled="!consent || submitting" @click="approve">
            <span v-if="submitting" class="spinner" aria-hidden="true" />
            {{ submitting ? '正在授权…' : '同意并继续' }}
          </button>
        </div>
      </template>
      <button v-else-if="token && request" class="btn secondary block" type="button" @click="loadPreview">重新核对</button>

      <div v-if="returnUrl" class="manual-code">
        <p class="manual-title">已签发一次性授权码</p>
        <p class="manual-desc">若没有自动跳转，请<a :href="returnUrl" rel="noreferrer">返回 CLI</a>；也可复制下方授权码，粘贴回发起授权的对话。<strong>不要向任何人发送密码。</strong></p>
        <div class="code-row">
          <input :value="manualCode" readonly aria-label="一次性授权码">
          <button class="btn secondary" type="button" @click="copyCode">{{ copied ? '已复制' : '复制' }}</button>
        </div>
      </div>

      <p class="footer-note">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /></svg>
        只授权你信任的应用。你可以随时在<NuxtLink to="/openauth/authorizations">应用授权管理</NuxtLink>中解绑。
      </p>
    </section>
    <LoginModal v-model="loginVisible" @success="loadPreview" />
  </main>
</template>

<style scoped>
.consent-page {
  position: relative;
  min-height: 100vh;
  display: grid;
  place-items: center;
  padding: var(--space-7) var(--space-5);
  background: var(--bg-soft);
  overflow: hidden;
}

.page-glow {
  position: absolute;
  inset: 0;
  pointer-events: none;
  background:
    radial-gradient(520px 320px at 12% -6%, var(--brand-100), transparent 65%),
    radial-gradient(460px 300px at 96% 104%, var(--accent-violet-soft), transparent 68%);
}

html.dark .page-glow {
  opacity: 0.5;
}

.consent-card {
  position: relative;
  width: 100%;
  max-width: 540px;
  padding: var(--space-7) var(--space-6) var(--space-6);
  background: var(--bg-elevated);
  border: 1px solid var(--ink-200);
  border-radius: var(--radius-xl);
  box-shadow: var(--shadow-lg);
}

.site-brand {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  color: var(--ink-900);
  font-weight: 750;
  font-size: 15px;
  text-decoration: none;
  transition: opacity 0.2s;
}

.site-brand:hover { opacity: 0.8; }

.brand-mark {
  display: grid;
  place-items: center;
  width: 34px;
  height: 34px;
  border-radius: 10px;
  background: linear-gradient(135deg, var(--brand-500) 0%, var(--accent-violet) 100%);
  box-shadow: 0 4px 10px rgba(47, 107, 255, 0.35);
}

.brand-divider {
  color: var(--ink-400);
  font-size: 12px;
  border-left: 1px solid var(--ink-300);
  padding-left: 10px;
  font-weight: 500;
}

.eyebrow {
  margin: var(--space-6) 0 var(--space-2);
  color: var(--brand-500);
  font-size: 12px;
  font-weight: 700;
  letter-spacing: 0.12em;
}

h1 {
  font-size: 27px;
  letter-spacing: -0.02em;
  color: var(--ink-900);
  margin: 0 0 var(--space-3);
  line-height: 1.25;
}

.intro {
  color: var(--ink-500);
  font-size: 14px;
  line-height: 1.75;
  margin: 0 0 var(--space-4);
}

.application {
  display: flex;
  gap: var(--space-4);
  align-items: center;
  margin: var(--space-5) 0 var(--space-4);
}

.app-icon {
  width: 52px;
  height: 52px;
  flex-shrink: 0;
  border-radius: 15px;
  background: linear-gradient(135deg, var(--brand-500) 0%, var(--accent-violet) 100%);
  display: grid;
  place-items: center;
  color: #fff;
  font-size: 23px;
  font-weight: 700;
  box-shadow: 0 6px 14px rgba(47, 107, 255, 0.3);
}

.app-meta h2 {
  margin: 0 0 3px;
  font-size: 18px;
  color: var(--ink-900);
  letter-spacing: -0.01em;
}

.app-meta p {
  margin: 0;
  color: var(--ink-500);
  font-size: 13px;
  line-height: 1.6;
}

.account {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: var(--space-3);
  padding: 13px 16px;
  background: var(--bg-soft);
  border: 1px solid var(--ink-200);
  border-radius: var(--radius-sm);
  font-size: 14px;
}

.account-label { color: var(--ink-500); }
.account-name { font-weight: 650; color: var(--ink-900); }

.section-title {
  font-size: 13px;
  font-weight: 700;
  color: var(--ink-700);
  margin: var(--space-5) 0 var(--space-3);
}

.permissions {
  padding: 0;
  margin: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
}

.permissions li {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 11px 14px;
  background: var(--accent-green-soft);
  border-radius: var(--radius-sm);
  font-size: 14px;
  font-weight: 550;
  color: var(--ink-700);
}

.perm-check {
  display: grid;
  place-items: center;
  width: 20px;
  height: 20px;
  flex-shrink: 0;
  border-radius: 50%;
  background: var(--accent-green);
  color: #fff;
}

.muted { color: var(--ink-400); font-size: 13px; line-height: 1.7; margin: var(--space-3) 0 0; }

.callback-row {
  display: flex;
  align-items: center;
  gap: 7px;
  margin-top: var(--space-3);
  font-size: 12px;
  color: var(--ink-400);
}

.callback-row svg { flex-shrink: 0; }
.callback-host { font-weight: 600; overflow-wrap: anywhere; }

.consent-check {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  font-size: 14px;
  line-height: 1.6;
  color: var(--ink-700);
  margin: var(--space-5) 0;
  cursor: pointer;
}

.consent-check input { margin-top: 4px; accent-color: var(--brand-500); }

.actions { display: flex; gap: var(--space-3); }

.btn {
  min-height: 48px;
  padding: 12px 22px;
  font-size: 15px;
  font-weight: 650;
  border-radius: var(--radius-sm);
  cursor: pointer;
  transition: background-color 0.2s, transform 0.2s, border-color 0.2s;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
}

.btn.primary {
  flex: 1;
  background: var(--brand-500);
  border: 1px solid var(--brand-500);
  color: #fff;
  box-shadow: 0 6px 16px rgba(47, 107, 255, 0.3);
}

.btn.primary:hover:not(:disabled) { background: var(--brand-600); transform: translateY(-1px); }

.btn.secondary {
  background: var(--bg-elevated);
  border: 1px solid var(--ink-300);
  color: var(--ink-700);
}

.btn.secondary:hover:not(:disabled) { border-color: var(--brand-500); color: var(--brand-600); }

.btn:disabled { opacity: 0.5; cursor: not-allowed; }
.btn.block { width: 100%; }

.notice {
  display: flex;
  align-items: flex-start;
  gap: 9px;
  background: var(--brand-50);
  color: var(--ink-700);
  padding: 13px 15px;
  border-radius: var(--radius-sm);
  margin: var(--space-4) 0;
  font-size: 13.5px;
  line-height: 1.7;
}

.notice svg { flex-shrink: 0; margin-top: 3px; color: var(--brand-500); }

.notice.error {
  background: #fff1f0;
  color: #a53232;
}

html.dark .notice.error { background: #3a1a1e; color: #f3a5a8; }

.manual-code {
  margin-top: var(--space-4);
  padding: var(--space-4);
  background: var(--bg-soft);
  border: 1px dashed var(--ink-300);
  border-radius: var(--radius-md);
}

.manual-title { margin: 0 0 6px; font-size: 14px; font-weight: 700; color: var(--ink-900); }
.manual-desc { margin: 0 0 var(--space-3); font-size: 12.5px; line-height: 1.7; color: var(--ink-500); }
.manual-desc strong { color: var(--ink-700); }

.code-row { display: flex; gap: var(--space-2); }

.code-row input {
  flex: 1;
  min-width: 0;
  height: 42px;
  padding: 0 13px;
  background: var(--bg-elevated);
  border: 1px solid var(--ink-300);
  border-radius: var(--radius-sm);
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 13px;
  color: var(--ink-900);
}

.code-row .btn { min-height: 42px; padding: 0 16px; }

.footer-note {
  display: flex;
  align-items: flex-start;
  gap: 7px;
  margin: var(--space-5) 0 0;
  padding-top: var(--space-4);
  border-top: 1px solid var(--ink-200);
  font-size: 12px;
  line-height: 1.7;
  color: var(--ink-400);
}

.footer-note svg { flex-shrink: 0; margin-top: 2px; }
.footer-note a { color: var(--brand-500); font-weight: 600; }

.state-icon.error { display: none; }

.spinner {
  width: 15px;
  height: 15px;
  border: 2px solid rgba(255, 255, 255, 0.4);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
  flex-shrink: 0;
}

.notice .spinner {
  border-color: rgba(47, 107, 255, 0.25);
  border-top-color: var(--brand-500);
}

@keyframes spin { to { transform: rotate(360deg); } }

button:focus-visible, input:focus-visible, a:focus-visible {
  outline: 3px solid var(--brand-200);
  outline-offset: 3px;
}

@media (max-width: 560px) {
  .consent-card { padding: var(--space-6) var(--space-5) var(--space-5); }
  .consent-page { padding: var(--space-5) var(--space-4); }
  h1 { font-size: 24px; }
}
</style>
