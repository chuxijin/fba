export default defineNuxtRouteMiddleware((to, from) => {
  // 从已加载统计脚本的普通页面进入授权区时创建全新文档，避免 SPA 继承回放脚本。
  if (import.meta.client && to.path.startsWith('/openauth/')
    && !from.path.startsWith('/openauth/') && from.matched.length > 0)
    return navigateTo(to.fullPath, { external: true })
})
