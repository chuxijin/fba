export interface AuthorizationRequest {
  client_id: string
  scopes: string[]
  redirect_uri: string
  state: string
  code_challenge: string
  code_challenge_method: 'S256'
}

export interface AuthorizationPreview {
  client_id: string
  name: string
  description: string | null
  scopes: string[]
  already_authorized: boolean
}

export function parseAuthorizationQuery(query: Record<string, unknown>): AuthorizationRequest {
  function scalar(key: string) {
    const value = query[key]
    if (typeof value !== 'string' || !value)
      throw new Error('授权链接缺少参数或包含重复参数，请从 CLI 重新发起登录')
    return value
  }
  const clientId = scalar('client_id')
  const state = scalar('state')
  const codeChallenge = scalar('code_challenge')
  const method = scalar('code_challenge_method')
  const redirectUri = scalar('redirect_uri')
  const scopes = [...new Set(scalar('scope').split(/\s+/).filter(Boolean))]
  const redirect = new URL(redirectUri)
  if (clientId.length > 64 || state.length < 16 || state.length > 512
    || !/^[A-Za-z0-9_-]{43}$/.test(codeChallenge) || method !== 'S256'
    || !scopes.length || scopes.length > 50 || scopes.some(scope => !/^[a-z][a-z0-9:_-]{0,99}$/.test(scope))
    || redirect.username || redirect.password || redirect.hash || /[\s\\]/.test(redirectUri)
    || !(redirect.protocol === 'https:' || (redirect.protocol === 'http:'
      && ['127.0.0.1', 'localhost', '[::1]'].includes(redirect.hostname))))
    throw new Error('授权链接参数无效，请从 CLI 重新发起登录')
  return { client_id: clientId, state, code_challenge: codeChallenge, code_challenge_method: 'S256',
    redirect_uri: redirectUri, scopes }
}

export function authorizationCallback(
  request: AuthorizationRequest,
  result: { code?: string; redirect_uri?: string; state?: string | null; denied?: boolean },
) {
  if (!result.denied && (!result.code || result.redirect_uri !== request.redirect_uri || result.state !== request.state))
    throw new Error('授权结果与当前请求不一致，已停止跳转')
  const url = new URL(request.redirect_uri)
  for (const key of ['code', 'state', 'error', 'error_description']) url.searchParams.delete(key)
  url.searchParams.set('state', request.state)
  if (result.denied) url.searchParams.set('error', 'access_denied')
  else url.searchParams.set('code', result.code!)
  return url.href
}

export function scopeLabel(scope: string) {
  return scope === 'profile:read' ? '读取你的昵称、头像与账号标识' : `访问权限：${scope}`
}
