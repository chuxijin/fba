import { test } from 'node:test'
import assert from 'node:assert/strict'
import { parseAuthorizationQuery, authorizationCallback } from '../app/utils/openauth.ts'

const query = { client_id: 'test', scope: 'profile:read', state: 's'.repeat(32), code_challenge: 'c'.repeat(43),
  code_challenge_method: 'S256', redirect_uri: 'http://127.0.0.1:17888/callback' }

test('valid CLI query is mapped to backend request without verifier or tokens', () => {
  const result = parseAuthorizationQuery(query)
  assert.deepEqual(result.scopes, ['profile:read'])
  assert.equal('code_verifier' in result, false)
})

test('duplicate or unsafe parameters are rejected', () => {
  for (const change of [{ state: ['a', 'b'] }, { code_challenge: '' }, { code_challenge_method: 'plain' },
    { redirect_uri: 'javascript:alert(1)' }, { redirect_uri: 'https://user:pass@example.com/' }, { scope: '' }])
    assert.throws(() => parseAuthorizationQuery({ ...query, ...change }))
})

test('callback requires exact server echo and replaces only reserved parameters', () => {
  const request = parseAuthorizationQuery({ ...query, redirect_uri: 'https://app.example/callback?keep=1&code=old' })
  const target = new URL(authorizationCallback(request, { code: 'new-code', redirect_uri: request.redirect_uri, state: request.state }))
  assert.equal(target.searchParams.get('keep'), '1')
  assert.deepEqual(target.searchParams.getAll('code'), ['new-code'])
  assert.throws(() => authorizationCallback(request, { code: 'code', redirect_uri: 'https://evil.example/', state: request.state }))
  assert.throws(() => authorizationCallback(request, { code: 'code', redirect_uri: request.redirect_uri, state: 'wrong' }))
})

test('cancellation returns state without a code', () => {
  const request = parseAuthorizationQuery(query)
  const target = new URL(authorizationCallback(request, { denied: true }))
  assert.equal(target.searchParams.get('state'), request.state)
  assert.equal(target.searchParams.get('error'), 'access_denied')
  assert.equal(target.searchParams.has('code'), false)
})
