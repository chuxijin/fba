export default defineEventHandler((event) => {
  if (event.path.startsWith('/openauth/') || event.path.startsWith('/api/openauth/')) {
    setHeader(event, 'cache-control', 'no-store')
    setHeader(event, 'referrer-policy', 'no-referrer')
    setHeader(event, 'x-frame-options', 'DENY')
    setHeader(event, 'content-security-policy', "frame-ancestors 'none'")
    setHeader(event, 'x-robots-tag', 'noindex, nofollow, noarchive')
  }
})
